module.exports = {
    lintOnSave:false,
    runtimeCompiler: true, // 运行时版本是否需要编译
    transpileDependencies: [],
}