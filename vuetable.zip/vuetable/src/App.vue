<template>
  <div id="app">
    <Tables/>
  </div>
</template>

<script>
import Tables from "./components/table";
export default {
  name: 'app',
  components: {
    Tables
  }
}
</script>

<style>
</style>
